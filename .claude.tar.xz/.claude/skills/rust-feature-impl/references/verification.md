# Verification recipe — prove a change is invariant-safe before it ships

Load this before claiming a feature is done. The `invariant-guardian` agent runs the same
recipe independently — the implementer running it first means fewer round-trips. Every command
runs from the **worktree root**. Treat an *errored* command (not just a failed assertion) as a
FAIL, fail-closed — never read an empty/errored result as "clean."

## 0. Environment realities — handle these first
- **rtk wraps `cargo`/`git`.** The shell hook rewrites these to `rtk`, which *summarizes* output
  and can misreport exit codes and fmt/clippy diagnostics. When precise output matters, run
  `rtk proxy <cmd>` (raw passthrough) **or** redirect to a file and read it; capture the exit code
  with `; echo "exit=$?"` immediately after the command (not after a pipe).
- **Floating `stable` toolchain.** `rust-toolchain.toml` pins `channel = "stable"`, which on a
  given machine may be much newer than the MSRV (1.80) — newer rustfmt/clippy then flag the whole
  workspace. **Separate feature-introduced issues from pre-existing baseline:** stash only the
  changed files and re-run the check —
  `git stash push -q <changed files>; <check>; git stash pop -q`. If the same issue appears with
  the feature stashed (or in files the change never touched), it is **baseline** — report it as a
  NOTE, not a blocker. Only issues that appear *because of* the change are findings. (There is no
  `cargo fmt --check` CI gate in this repo; fmt is a local discipline.)
- **The clippy *axis* matters too: the gate form vs `--all-targets`.** The CI/CLAUDE.md gate is
  `cargo clippy --workspace -- -D warnings` (no `--all-targets`). The stricter
  `cargo clippy --workspace --all-targets` *also lints test code* and can surface findings the gate
  form never fires (this is the same per-repo `--all-targets` axis the preflight gate mirrors — see
  CLAUDE.md "Per-repo CI mirror"). Classify by **(a) which axis** and **(b) introduced vs
  pre-existing**: a finding in an **untouched** file under `--all-targets`-only is **inherited red**
  — report it as a NOTE with the `git diff --name-only` proof that the change didn't touch it, and
  do **not** block on it (and do **not** silently "fix" an untouched file to make it pass). But a
  finding in a file **the change touched** is a real finding even if it only fires under
  `--all-targets` — fix it. Never relax the gate command to make red disappear. (G2:
  `gui/main.rs:1997` fired only under `--all-targets`, in an untouched file → correctly inherited,
  NOTE not blocker.)

## Table of contents
1. The three CI gates
2. Cargo checks (fmt / clippy / test)
3. Engine purity (non-printing, logic-in-engine)
4. Front-end parity (CLI ↔ GUI ↔ Engine)
4.5. Runtime behavior (run the app at its surface — Phase 3.5)
5. Fail-closed / dry-run defaults
6. Rust-native drift
7. Lock / manifest honesty
8. Full pre-push sequence

---

## 1. The three CI gates

```bash
bash ci/gates/no-c.sh     # supply chain: no C in the trust boundary; one ring-only rustls
bash ci/gates/shape.sh    # code-shape: no native-roots/accept-invalid TLS; edge isolation
bash ci/gates/enable.sh   # secretd systemd-unit enable invariant
```

- **`no-c.sh`** parses the resolved `cargo metadata` graph and fails CLOSED if any of
  `aws-lc-sys`, `aws-lc-rs`, `openssl-sys`, `libsql-ffi`, `libsql-sys`, `sqlite3-sys`, `rusqlite`
  resolve into the graph, if more than one `rustls` version exists, or if `ring` is absent. Run
  it after **any** dependency change. A build-time `cc`/`lemon.c` (libSQL parser codegen that
  emits Rust and links nothing) is accepted — that is not a violation.
- **`shape.sh`** greps non-test Rust source for forbidden TLS tokens
  (`danger_accept_invalid_certs`, `rustls-tls-native-roots`, `use_native_tls`, …) and enforces
  edge-module isolation once the Phase-8 edge lands.
- **`enable.sh`** asserts `crates/secretd/src/main.rs` is no longer the `todo!()` scaffold and
  that an enabled systemd unit has a matching `secretd --self-check` surface in both manifest and
  source.

## 2. Cargo checks

```bash
cargo fmt --all -- --check
cargo clippy --workspace -- -D warnings
cargo test --workspace                 # or -p <crate> during the incremental pass
```

Never silence a clippy finding with a broad `#[allow]` to pass; fix the code or justify a narrow,
commented allow.

## 3. Engine purity

The engine library emits events; it does not print, and it holds the logic.

```bash
# No printing added to the engine library path:
git diff --unified=0 -- crates/engine | grep -nE '^\+.*(println!|eprint(ln)?!|print!|stdout\(\))' && echo "VIOLATION: engine printed" || echo "engine clean"
```

Also confirm by reading: new behavior lives in `crates/engine/src/`, not in `crates/cli/src/main.rs`
or `crates/gui`. clap/UI/printing belong to the front-ends only.

## 4. Front-end parity (the core cross-boundary check)

For each new or changed `Engine` method, prove **both** front-ends reach it (or the plan
justified an asymmetry). Don't existence-check — compare caller shapes.

```bash
# callers of the symbol across the workspace (AST-aware, not text):
git-kb code callers '<EngineMethod>' --json     # or kb_callers MCP
```

Expect to see a CLI call site (`crates/cli/...`) and a GUI call site (`crates/gui/...`). Read
both and confirm they pass/consume the same shape the engine expects/returns.

> Parity (callers exist, shapes match) is **structural** proof, not runtime proof. For an
> observable surface, also do §4.5 — running the app is the evidence parity can't give.

## 4.5. Runtime behavior (run the app at its surface — Phase 3.5)

Sections 1–4 prove the change is *well-formed*; they do not prove it *works*. For any feature whose
plan declares a **`## Runtime surface`** (CLI verb / GUI screen / daemon RPC / library export), drive
that surface with the bundled **`verify`** skill and capture the app's own output as evidence:

```bash
# build the REAL binary, then drive the smallest path that runs the changed code:
cargo run -p envctl -- <the declared verb + args>          # CLI surface
# daemon RPC: start secretd, send the request via secretctl, capture the response body
# GUI: drive under xvfb/Playwright, screenshot the screen
```

- **Observe, don't import-and-call.** Reach the surface the way a user does (CLI/socket/window),
  not by calling an internal fn — that's a unit test, not a runtime check.
- **Probe one off-happy-path input** (empty/blocked/conflicting flag, wrong method, malformed body,
  the fail-closed guard's *refusal* path) — capture what the app actually does.
- **Destructive/irreversible + no dry-run/safe target** → verify *around* it (refusal + dry-run
  preview) and state which live path was not exercised. Never run a destructive op live to watch it.
- **No surface** (docs/types/test-only/internal-refactor) → SKIP with that one-line reason. Don't
  re-run `cargo test` to fill the space — that proves CI runs, not that the feature works.

This is the guardian's Phase 3.5; its result is the `## Runtime check` line of the report. A clean
PASS requires a runtime observation (or a recorded SKIP); static gates alone are PASS-WITH-NOTES.

## 5. Fail-closed / dry-run defaults

For any destructive/mutating op introduced or touched:

- Confirm the default path is **preview** and mutation is gated behind `--apply`/`--build`.
- Confirm the guard (`UuidResolves` / `NotLiveDevice` / `NotMounted`) is invoked **before**
  mutation and refuses when it cannot prove safety.
- Confirm a unit test exercises the **refusal** path:

```bash
cargo test -p <crate> -- <guard_or_refuse_test_name>
```

A mutation op with only a happy-path test is incomplete.

- **Drive every refusal branch at runtime (Phase 3.5 deepening — §4.5).** A passing refusal *unit
  test* is necessary but not sufficient: also drive **each** guard's refusal path and the
  dry-run-vs-`--apply` split at the real surface and capture what the running app does (refusal without
  `--apply`; refusal when safety can't be proven; preview vs mutation). For a mutating op this is the
  highest-risk surface — confirming the *running* CLI/daemon actually refuses is the evidence, not just
  that a test for it compiles and passes.

## 6. Rust-native drift

```bash
# Any non-Rust source/package file newly added? (worktree against master)
git status --porcelain | grep -E '\.(js|ts|jsx|tsx|mjs|cjs|py|rb|omc)$|package\.json$|node_modules' \
  && echo "POSSIBLE DRIFT — verify before committing" || echo "no foreign source added"
```

A hit is not automatically a failure — confirm whether it is genuine language drift (reject /
port to Rust) or an accepted build-time artifact (e.g. the libSQL parser's `lemon.c` codegen,
which emits Rust and links nothing). When in doubt, treat as drift and report.

## 7. Lock / manifest honesty

If dependencies or declared components changed:

```bash
cargo run -p envctl -- lock --check          # envctl.lock still matches declared components
kasetto sync --locked                         # agent-env lock still satisfied (no fetch)
```

A green lock check means the committed reproducible state still reflects reality.

## 8. Full pre-push sequence

```bash
cargo fmt --all -- --check \
 && cargo clippy --workspace -- -D warnings \
 && cargo test --workspace \
 && bash ci/gates/no-c.sh \
 && bash ci/gates/shape.sh \
 && bash ci/gates/enable.sh \
 && echo "ALL GATES GREEN"
```

Only `ALL GATES GREEN` plus the parity + fail-closed + drift checks above earns a PASS verdict.
